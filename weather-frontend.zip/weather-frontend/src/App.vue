<template>
  <div class="app-container">
    <div class="weather-card">
      <h1 class="title">Weather App</h1>

      <label for="location" class="label">Select Location:</label>
      <select v-model="location" class="input">
        <option disabled value="">Choose a location</option>
        <option v-for="loc in locations" :key="loc" :value="loc">{{ loc }}</option>
      </select>

  
      <div class="date-range">
        <div>
          <label for="fromDate" class="label">From Date:</label>
          <input v-model="fromDate" type="date" class="input date-input" />
        </div>
        <div>
          <label for="toDate" class="label">To Date:</label>
          <input v-model="toDate" type="date" class="input date-input" />
        </div>
      </div>

      <button @click="fetchWeather" class="btn">
        Get Weather
      </button>

  
      <div v-if="errorMessage" class="error-message">
        {{ errorMessage }}
      </div>


      <div v-if="weatherData" class="weather-display">
        <p><strong>Location:</strong> {{ weatherData.location }}</p>
        <p class="temperature">
          <strong>Temperature:</strong> 
          {{ weatherData.temperature }}°C
        </p>
        <p><strong>Description:</strong> {{ weatherData.description }}</p>

        
      </div>

      <div class="random-test">
        <p><strong>Random Test:</strong> This is just a test message! The weather data above is displayed successfully.</p>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  name: 'App',
  data() {
    return {
      location: '',
      fromDate: '',
      toDate: '',
      weatherData: null,
      errorMessage: null,
      locations: ['Delhi', 'Moscow', 'Paris', 'New York', 'Sydney', 'Riyadh'],
    };
  },
  methods: {
    async fetchWeather() {
      this.errorMessage = null;

      if (!this.location || !this.fromDate || !this.toDate) {
        this.errorMessage = 'All fields are required.';
        return;
      }

      const from = new Date(this.fromDate);
      const to = new Date(this.toDate);
      const diff = (to - from) / (1000 * 60 * 60 * 24);

      if (diff < 0) {
        this.errorMessage = "'To Date' must be after 'From Date'.";
        return;
      }

      if (diff > 30) {
        this.errorMessage = 'Maximum allowed date range is 30 days.';
        return;
      }

      try {
        const response = await axios.post('http://localhost:8000/weather/history', {
          location: this.location,
          fromDate: this.fromDate,
          toDate: this.toDate,
        });
        this.weatherData = response.data;
      } catch (error) {
        this.errorMessage = 'Failed to fetch weather data.';
        console.error(error);
      }
    },

   
  },
};
</script>

<style scoped>
.app-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  background-color:rgb(117, 198, 231);
  margin: 0;
  font-family: 'Roboto', sans-serif;
}
.weather-card {
  background-color: #ffffff;
  padding: 30px;
  border-radius: 15px;
  box-shadow: 0 4px 15px rgba(231, 98, 98, 0.1);
  width: 100%;
  max-width: 600px;
  text-align: center;
  box-sizing: border-box;
  transition: transform 0.3s ease;
}

.weather-card:hover {
  transform: scale(1.05);
}

.title {
  font-size: 2.5rem;
  font-weight: bold;
  margin-bottom: 20px;
  color: #333;
}
.label {
  display: block;
  font-size: 1rem;
  margin-bottom: 5px;
  color: #444;
}
.input {
  width: 100%;
  padding: 12px;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 1rem;
  margin-bottom: 20px;
  box-sizing: border-box;
  transition: border-color 0.3s;
}

.input:focus {
  outline: none;
  border-color: #007bff;
}
.date-input {
  background-color: #f4f6f9;
  border: 1px solid #ddd;
  color: #333;
  font-size: 1rem;
}

.date-input:focus {
  border-color: #007bff;
}

.date-range {
  display: flex;
  justify-content: space-between;
  gap: 20px;
  margin-bottom: 20px;
}

.date-range div {
  width: 48%;
}

.btn {
  width: 100%;
  padding: 12px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 1.1rem;
  cursor: pointer;
  transition: background-color 0.3s;
}

.btn:hover {
  background-color: #0056b3;
}

.error-message {
  color: red;
  font-weight: bold;
  margin-top: 10px;
}

.weather-display {
  background-color: #f9f9f9;
  padding: 20px;
  border-radius: 8px;
  margin-top: 25px;
  text-align: center;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
  background-color: #eef4f9;  /* Light blue background for weather info */
}

.weather-display p {
  margin: 10px 0;
  font-size: 1.1rem;
}
.temperature {
  font-size: 1.2rem;
  font-weight: bold;
  color: #333;
}

.temp-symbol {
  font-size: 1.5rem;
  color: #ff6347; /* Tomato color for temperature symbol */
}

.weather-icon {
  margin-top: 15px;
  width: 60px;
  height: 60px;
}

.random-test {
  background-color:rgb(32, 122, 185);
  padding: 15px;
  margin-top: 30px;
  border-radius: 8px;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
}

.random-test p {
  font-size: 1.1rem;
  font-weight: bold;
  color: #333;
}

@media (max-width: 600px) {
  .weather-card {
    padding: 20px;
  }

  .title {
    font-size: 2rem;
  }

  .input {
    padding: 10px;
font-size: 0.9rem;
  }

  .btn {
    padding: 10px;
  }

  .weather-icon {
    width: 40px;
    height: 40px;
  }

  .temperature {
    font-size: 1rem;
  }
}
</style>



